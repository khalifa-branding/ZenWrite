// ZenWrite Global Configuration File
// Set your Gemini API Key here for a permanent, universal solution across all browsers,
// even if you clear your browser cache, change settings, or run offline.
const ZENWRITE_CONFIG = {
    apiKey: "AQ.Ab8RN6Jl_5ww3Z02h-ca0lrlGsMtscLodyaqXJM1_HJDe7J5kA",
    aiModel: "gemini-3.6-flash"
};
